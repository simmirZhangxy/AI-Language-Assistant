"""
@file __init__.py
@brief dmcan 包入口：导出与 libdmcan 2.0.x 对应的类型、异常与设备封装。
"""

__version__ = "2.1.1"
"""Python 封装版本；主版本跟随所支持的 libdmcan 对外 ABI（见 `dmcan_def.DMCAN_ABI_MAJOR`）。"""

from dmcan.dmcan_def import *
from dmcan.dmcan_device import *
from dmcan.dmcan_context import *
