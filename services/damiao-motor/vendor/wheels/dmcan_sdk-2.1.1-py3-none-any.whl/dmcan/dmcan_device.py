"""
@file dmcan_device.py
@brief DmCanDevice：libdmcan 2.0.x 设备级接口（通道 / 波特率 / 发送 / 回调）的 Python 封装。

@note 2.0.0 起 v1.x 的 `dmcan_device_fill_can_queue()` 与 `dmcan_device_can_queue_send()` 已从库中
      删除：批量发送改用 `send_can_batch()`（数组版，一次交一批、没有跨调用残留状态），
      递增发送改用 `send_can_bulk()`。
"""

import time
from ctypes import *
from typing import Any, Callable, Optional, Sequence

from dmcan.dmcan_def import (DEV_ERR_CALLBACK, DEV_EVENT_CALLBACK, DEV_RECV_CALLBACK,
                             DEV_SENT_CALLBACK, DMCAN_ABI_HINT, DMCAN_CHANNEL_MASK_ALL,
                             DmCanDeviceInfo, DmCanError, DmCanEvent, device_type_of,
                             dmcan_bulk_send_config, dmcan_bus_state, dmcan_ch_baud_conf,
                             dmcan_channel_can_info, dmcan_channel_error, dmcan_channel_ext_config,
                             dmcan_channel_mode, dmcan_channel_stats, dmcan_device_handle,
                             dmcan_echo_stats, dmcan_event, dmcan_event_flag, dmcan_filter_rule,
                             dmcan_filter_table, dmcan_filter_usage, dmcan_firmware_info,
                             dmcan_frame, dmcan_module_feature, dmcan_rx_frame, dmcan_send_profile,
                             dmcan_status, dmcan_subscribe_config, dmcan_subscription,
                             dmcan_tdc_status, dmcan_uart_config, dmcan_uart_stats, payload_buffer,
                             status_of)


class DmCanSubscription:
    """一次订阅的句柄：`cancel()` 注销（等价于 `DmCanDevice.unsubscribe()`）。"""

    def __init__(self, device, subscription, wrapper, user_callback):
        """
        @param device 订阅所属设备
        @param subscription C 侧订阅句柄
        @param wrapper 回调外壳；**必须持有**，被回收会让 C 侧的函数指针变成野指针
        @param user_callback 用户回调（仅作记录）
        """
        self._device = device
        self._subscription = subscription
        self._wrapper = wrapper
        self._user_callback = user_callback
        self._active = True

    @property
    def active(self) -> bool:
        """@brief 订阅是否仍然有效（`cancel()` 之后为 False）。"""
        return self._active

    def cancel(self) -> None:
        """@brief 注销订阅（可重复调用）。"""
        if self._active:
            self._device.unsubscribe(self)


def _decode_event(event: dmcan_event) -> DmCanEvent:
    """
    @brief 把 C 侧事件结构拷成 Python 对象。

    @param event C 回调给的事件（其内部指针只在回调期间有效）
    @return `DmCanEvent`，帧/错误/UART 数据都已拷贝
    """
    frame = error = uart = None
    if event.frame:
        frame = dmcan_rx_frame.from_buffer_copy(string_at(event.frame, sizeof(dmcan_rx_frame)))
    if event.error:
        error = dmcan_channel_error.from_buffer_copy(string_at(event.error, sizeof(dmcan_channel_error)))
    if event.uart:
        chunk = event.uart.contents
        uart = string_at(chunk.data, chunk.length) if chunk.length else b""
    return DmCanEvent(dmcan_event_flag(event.type), event.channel, frame, error, uart)


class DmCanDevice:
    """一台设备的会话封装；由 `DmCanContext.find_devices()` 创建。"""

    def __init__(self, dll: CDLL, handle: POINTER(dmcan_device_handle), index: int):
        """
        @param dll 已加载的 libdmcan
        @param handle `dmcan_device_get()` 取到的设备句柄
        @param index 句柄在设备表里的下标（见 `DmCanContext.find_devices()`）

        @note 一般不直接 new：句柄的生命周期由 `DmCanContext` 持有。
        """
        self.index = index
        self.dll = dll
        self._handle = handle
        self._recv_callback: Optional[Callable] = None
        self._sent_callback: Optional[Callable] = None
        self._error_callback: Optional[Callable] = None

        self._recv_cb_wrapper: Optional[Callable] = None
        self._sent_cb_wrapper: Optional[Callable] = None
        self._error_cb_wrapper: Optional[Callable] = None

        self._init_funcs()

    def _bind(self, name: str, argtypes: list, restype) -> None:
        """
        @brief 绑定一个导出符号并声明参数/返回类型。

        @param name 符号名
        @param argtypes 参数类型列表
        @param restype 返回类型

        @note 符号缺失说明库与绑定不配套（例如拿着 2.0.0 之前的旧库），这里直接给出明确报错，
              而不是留一个 AttributeError 让调用方去猜。
        """
        try:
            func = getattr(self.dll, name)
        except AttributeError as exc:
            raise RuntimeError(f"libdmcan 缺少符号 {name}：库与 dmcan {DMCAN_ABI_HINT} 绑定不配套") from exc
        func.argtypes = argtypes
        func.restype = restype

    def _init_funcs(self):

        self._bind("dmcan_device_open", [POINTER(dmcan_device_handle)], c_bool)
        self._bind("dmcan_device_close", [POINTER(dmcan_device_handle)], None)

        self._bind("dmcan_device_get_firmware_info",
                   [POINTER(dmcan_device_handle), POINTER(dmcan_firmware_info)], c_bool)
        self._bind("dmcan_firmware_info_to_string",
                   [POINTER(dmcan_firmware_info), c_char_p, c_uint32], c_uint32)

        self._bind("dmcan_device_enable_channel", [POINTER(dmcan_device_handle), c_uint8], c_bool)
        self._bind("dmcan_device_disable_channel", [POINTER(dmcan_device_handle), c_uint8], c_bool)

        self._bind("dmcan_device_get_channel_baudrate",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_channel_can_info)], c_bool)
        self._bind("dmcan_device_set_channel_baudrate",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_channel_can_info)], c_bool)
        self._bind("dmcan_device_get_channel_baudrate_details",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_ch_baud_conf)], c_bool)
        self._bind("dmcan_device_set_channel_baudrate_details",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_ch_baud_conf)], c_bool)

        self._bind("dmcan_device_hook_recv_callback", [POINTER(dmcan_device_handle), DEV_RECV_CALLBACK], None)
        self._bind("dmcan_device_hook_sent_callback", [POINTER(dmcan_device_handle), DEV_SENT_CALLBACK], None)
        self._bind("dmcan_device_hook_err_callback", [POINTER(dmcan_device_handle), DEV_ERR_CALLBACK], None)

        self._bind("dmcan_device_send_can",
                   [POINTER(dmcan_device_handle), c_uint8, c_uint32, c_bool, c_bool, c_bool, c_bool,
                    c_uint8, POINTER(c_uint8)], c_bool)
        self._bind("dmcan_device_send_can_details",
                   [POINTER(dmcan_device_handle), c_uint8, c_uint32, c_uint32, c_uint32,
                    c_bool, c_bool, c_bool, c_bool, c_uint8, POINTER(c_uint8)], c_bool)
        self._bind("dmcan_device_send_can_batch",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_frame), c_uint32], c_bool)
        self._bind("dmcan_device_send_can_bulk",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_bulk_send_config)], c_bool)
        self._bind("dmcan_device_stop_send", [POINTER(dmcan_device_handle), c_uint8], c_bool)

        self._bind("dmcan_device_is_present", [POINTER(dmcan_device_handle), POINTER(c_bool)], c_bool)
        self._bind("dmcan_device_get_info",
                   [POINTER(dmcan_device_handle), POINTER(c_int), POINTER(c_int), POINTER(c_int),
                    POINTER(POINTER(c_ubyte))], None)
        self._bind("dmcan_device_get_channel_tdc",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_tdc_status)], c_bool)
        self._bind("dmcan_device_save_param", [POINTER(dmcan_device_handle)], c_bool)
        self._bind("dmcan_device_set_channel_filter",
                   [POINTER(dmcan_device_handle), c_uint8, c_uint8, POINTER(dmcan_filter_rule), c_uint16,
                    POINTER(dmcan_filter_usage)], c_bool)
        self._bind("dmcan_device_get_channel_filter",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_filter_table)], c_bool)
        self._bind("dmcan_device_enable_watchdog", [POINTER(dmcan_device_handle), c_uint16, c_bool], c_bool)

        self._bind("dmcan_device_subscribe",
                   [POINTER(dmcan_device_handle), POINTER(dmcan_subscribe_config),
                    POINTER(POINTER(dmcan_subscription))], c_bool)
        self._bind("dmcan_device_unsubscribe",
                   [POINTER(dmcan_device_handle), POINTER(dmcan_subscription)], c_bool)

        self._bind("dmcan_device_set_send_profile", [POINTER(dmcan_device_handle), c_int], c_bool)
        self._bind("dmcan_device_get_send_profile", [POINTER(dmcan_device_handle), POINTER(c_int)], c_bool)
        self._bind("dmcan_device_get_channel_ext_config",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_channel_ext_config)], c_bool)
        self._bind("dmcan_device_set_channel_ext_config",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_channel_ext_config)], c_bool)
        self._bind("dmcan_device_get_module_features",
                   [POINTER(dmcan_device_handle), POINTER(c_uint16)], c_bool)
        self._bind("dmcan_device_enable_can_res",
                   [POINTER(dmcan_device_handle), c_uint8, c_bool], c_bool)
        self._bind("dmcan_device_get_can_res",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(c_bool)], c_bool)
        self._bind("dmcan_device_set_channel_echo",
                   [POINTER(dmcan_device_handle), c_uint8, c_bool], c_bool)
        self._bind("dmcan_device_get_echo_stats",
                   [POINTER(dmcan_device_handle), POINTER(dmcan_echo_stats)], c_bool)
        self._bind("dmcan_device_set_echo_timeout_ms", [POINTER(dmcan_device_handle), c_uint32], None)
        self._bind("dmcan_device_clear_bus_off", [POINTER(dmcan_device_handle), c_uint8], c_bool)
        self._bind("dmcan_device_get_channel_stats",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_channel_stats)], c_bool)
        self._bind("dmcan_device_get_bus_state",
                   [POINTER(dmcan_device_handle), c_uint8, POINTER(dmcan_bus_state)], c_bool)

        self._bind("dmcan_device_set_uart_auto_open", [POINTER(dmcan_device_handle), c_bool], c_bool)
        self._bind("dmcan_device_set_uart_config",
                   [POINTER(dmcan_device_handle), POINTER(dmcan_uart_config)], c_bool)
        self._bind("dmcan_device_uart_is_open", [POINTER(dmcan_device_handle), POINTER(c_bool)], c_bool)
        self._bind("dmcan_device_uart_get_port_name",
                   [POINTER(dmcan_device_handle), c_char_p, c_uint32], c_bool)
        self._bind("dmcan_device_uart_open",
                   [POINTER(dmcan_device_handle), POINTER(dmcan_uart_config)], c_bool)
        self._bind("dmcan_device_uart_close", [POINTER(dmcan_device_handle)], None)
        self._bind("dmcan_device_uart_write",
                   [POINTER(dmcan_device_handle), POINTER(c_uint8), c_uint32], c_bool)
        self._bind("dmcan_device_get_uart_stats",
                   [POINTER(dmcan_device_handle), POINTER(dmcan_uart_stats)], c_bool)

        self._bind("dmcan_get_last_error", [], c_int)
        self._bind("dmcan_clear_last_error", [], None)

    def last_error(self):
        """
        @brief 读本线程最后一次失败的错误码（`dmcan_get_last_error`，线程局部）。

        @return `dmcan_status` 成员；比本绑定新的未收录取值原样返回整数
        """
        return status_of(self.dll.dmcan_get_last_error())

    def _check(self, result, api: str) -> None:
        """
        @brief 统一的失败处理：C 侧返回 false 就按 `dmcan_get_last_error()` 抛 `DmCanError`。

        @param result C 接口的返回值
        @param api 接口名（报错信息里带上，便于定位）
        """
        if not result:
            raise DmCanError(self.last_error(), api)

    def open(self) -> None:
        """
        @brief 打开设备（USB 会话）。

        @note 默认会同时按 VID/PID + 序列号自动打开本机的 UART 虚拟串口并**独占**它
              （app 侧脚本 / 串口助手此时打不开）；不需要 UART 时要在 C 侧 `open` 之前关掉自动打开。
        @note 失败抛 `DmCanError`（常见原因：设备被拔掉、被别的进程占用）。
        """
        self._check(self.dll.dmcan_device_open(self._handle), "dmcan_device_open")

    def close(self) -> None:
        """@brief 关闭设备（可重复调用）。"""
        self.dll.dmcan_device_close(self._handle)

    def get_firmware_info(self) -> dmcan_firmware_info:
        """
        @brief 读设备型号 + 固件发布版本 + 构建标识（`dmcan_device_get_firmware_info`）。

        @return `dmcan_firmware_info`；两个 `*_valid` 分别表示“这次读到了没有”

        @note 只读到其中一样（例如老固件没在应答尾部带构建标识）也算成功；**两样都没读到**才抛
              `DmCanError`（错误码 `IO`）。
        @note 2.0.1 的 `dmcan_device_get_version()` / `get_version_string()` / `print_version()` /
              `get_build_info_string()` 在 2.1 已合并到本接口，一条 `CMD_GET_VERSION` 拿全。
        @note 需要设备已 `open()`，未打开会抛 `DmCanError(NOT_OPEN)`。
        """
        info = dmcan_firmware_info()
        self._check(self.dll.dmcan_device_get_firmware_info(self._handle, byref(info)),
                    "dmcan_device_get_firmware_info")
        return info

    def get_version(self) -> str:
        """
        @brief 把固件信息格式化成人读的一行（`dmcan_firmware_info_to_string`，纯格式化、不访问设备）。

        @return 形如 `USB2CANFD_D V2.0.1 [7500b44 2026-09-24 15:23:06]`；没有构建标识时只有型号与
                版本号；`*_valid` 为假的那一段不会被印成 0.0.0
        """
        info = self.get_firmware_info()
        buffer = create_string_buffer(128)
        written = self.dll.dmcan_firmware_info_to_string(byref(info), buffer, len(buffer))
        if not written:
            raise DmCanError(self.last_error(), "dmcan_firmware_info_to_string")
        return buffer.value.decode("utf-8", errors="replace")

    def enable_channel(self, channel: int, enable: bool) -> None:
        """
        @brief 使能 / 关闭通道。

        @param channel 通道号，范围见设备型号（单路 `0`，双路 `0/1`）
        @param enable True = 使能，False = 关闭

        @note 关闭走 `disable_channel()`，因此同样带"接口谎报失败"的复核逻辑。
        """
        if enable:
            self._check(self.dll.dmcan_device_enable_channel(self._handle, channel), "dmcan_device_enable_channel")
        else:
            self.disable_channel(channel)

    def disable_channel(self, channel: int, verify: bool = True) -> None:
        """
        @brief 关闭通道（`dmcan_device_disable_channel`）。

        @param channel 通道号
        @param verify 接口回 false 时是否用固件统计复核实际状态（默认开）

        @note **已知 C 侧缺陷（2.0.1 真机实测）**：`dmcan_device_disable_channel()` 在通道**确实已经
              关闭**的情况下仍会返回 false（它只看 ACK 首个数据字节的布尔，而固件对这条命令回 0），
              错误码是 `IO`。实测：固件侧 `enabled` 1→0、随后发帧被计入 `tx_dropped`，接口却回失败。
              这会让"改位定时前先关通道"的标准流程直接报错，所以这里在 false 时用
              `dmcan_channel_stats::enabled` 复核：确认已关闭就正常返回，复核不到才抛 `DmCanError`。
        @note 复核只在走异常分支时发生，且统计是 1 Hz 上报，最多等约 2.6 s。
        """
        result = self.dll.dmcan_device_disable_channel(self._handle, channel)
        status = self.last_error()
        if result:
            return
        if verify and self._wait_channel_disabled(channel):
            return
        raise DmCanError(status, "dmcan_device_disable_channel")

    def _wait_channel_disabled(self, channel: int, timeout: float = 2.6) -> bool:
        """
        @brief 轮询固件统计，确认通道已经关闭。

        @param channel 通道号
        @param timeout 最长等待时间，单位秒
        @return True 表示读到 `enabled == 0`
        """
        deadline = time.time() + timeout
        while True:
            try:
                stats = self.get_channel_stats(channel)
                if stats is not None and not stats.enabled:
                    return True
            except DmCanError:
                pass
            if time.time() >= deadline:
                return False
            time.sleep(1.2)

    def get_channel_baudrate(self, channel: int) -> dmcan_channel_can_info:
        """
        @brief 读通道波特率（`dmcan_channel_can_info_t`，不含 TDC）。

        @param channel 通道号
        @return 填好的 `dmcan_channel_can_info`
        """
        info = dmcan_channel_can_info()
        self._check(self.dll.dmcan_device_get_channel_baudrate(self._handle, channel, info),
                    "dmcan_device_get_channel_baudrate")
        return info

    def set_channel_baudrate(self, channel: int, info: dmcan_channel_can_info) -> None:
        """
        @brief 写通道波特率（`dmcan_channel_can_info_t`）。

        @param channel 通道号
        @param info 波特率参数

        @note TDC（发送延迟补偿）由库自动决定：CAN FD 且数据段 > 1 Mbps 时打开，其余关闭；
              要看/要改 TDC 请走 `get_channel_baudrate_details()` / `set_channel_baudrate_details()`。
        @note 本接口只改运行期参数，**掉电/拔插会丢**，要保留需另调 `dmcan_device_save_param()`。
        """
        self._check(self.dll.dmcan_device_set_channel_baudrate(self._handle, channel, info),
                    "dmcan_device_set_channel_baudrate")

    def get_channel_baudrate_details(self, channel: int) -> dmcan_ch_baud_conf:
        """
        @brief 读通道位定时的完整配置（`dmcan_ch_baud_conf_t`，含 `enable_tdc` 与 `busoff_autoreset_ms`）。

        @param channel 通道号
        @return 填好的 `dmcan_ch_baud_conf`

        @note 回读的是"下发原值"；TDC 的**硬件实际生效值**要另走 `dmcan_device_get_channel_tdc()`（本绑定尚未封装）。
        """
        config = dmcan_ch_baud_conf()
        self._check(self.dll.dmcan_device_get_channel_baudrate_details(self._handle, channel, config),
                    "dmcan_device_get_channel_baudrate_details")
        return config

    def set_channel_baudrate_details(self, channel: int, config: dmcan_ch_baud_conf) -> None:
        """
        @brief 按完整下发结构写通道参数（字段逐一对应固件布局）。

        @param channel 通道号
        @param config 位定时配置；`reserved` 必须为 0，`tdc_offset` / `tdc_filter` 只有低 7 位有效

        @note 下发与硬件生效不同步（固件每秒任务里重载，实测 0.086 ~ 1.0 s），刚写完回读可能是旧值。
        """
        self._check(self.dll.dmcan_device_set_channel_baudrate_details(self._handle, channel, config),
                    "dmcan_device_set_channel_baudrate_details")

    def set_channel_mode(self, channel: int, mode) -> None:
        """
        @brief 设置通道的 MCAN 节点模式（2.1 新增，通过 `dmcan_ch_baud_conf.mode` 下发）。

        @param channel 通道号
        @param mode `dmcan_channel_mode` 取值

        @note 实现是“读回当前 `dmcan_ch_baud_conf` → 只改 `mode` → 写回”，其余字段原样保留。
        @note 与改位定时同规矩：**先 `disable_channel()`、写完再 `enable_channel()`**；下发到生效
              不同步（固件每秒任务里重载，实测 0.086 ~ 1.0 s）。
        @note 单模块自测用 `LOOPBACK_EXTERNAL`：帧照常驱动总线并回环到自己，**不依赖外部 ACK**，
              同一通道即可自发自收。
        """
        config = self.get_channel_baudrate_details(channel)
        config.mode = int(mode)
        self.set_channel_baudrate_details(channel, config)

    def send_can(self, channel: int, can_id: int, payload: bytes = b"", canfd: bool = False,
                 ext: bool = False, rtr: bool = False, brs: bool = False) -> None:
        """
        @brief 发送一帧（`dmcan_device_send_can`）。

        @param channel 通道号
        @param can_id 帧 ID（标准帧 ≤ 0x7FF，扩展帧 ≤ 0x1FFFFFFF）
        @param payload 数据（0~64 字节）；数据长度直接取它的长度，无需另传
        @param canfd 是否 CAN FD 帧；经典帧数据超过 8 字节会被库拒收
        @param ext 是否扩展帧
        @param rtr 是否远程帧（不带数据）
        @param brs 是否启用 BRS（仅 CAN FD 有意义）

        @note 数据长度不在 DLC 表里（9~11 等）时由库自动向上取整到最近的 DLC，线上尾部补 0。
        @note 返回即"已受理"，**不代表已经发到总线**；要总线确认请挂 sent 回调看 `ack = 1` 的真 echo。
        """
        data = b"" if rtr else bytes(payload)
        buffer = payload_buffer(data)
        self._check(self.dll.dmcan_device_send_can(self._handle, channel, can_id, canfd, ext, rtr, brs,
                                                   len(data), buffer), "dmcan_device_send_can")

    def send_can_details(self, channel: int, can_id: int, interval_ms: int, payload: bytes = b"",
                         send_times: int = 0, canfd: bool = False, ext: bool = False,
                         rtr: bool = False, brs: bool = False) -> None:
        """
        @brief 单次 / 周期发送（`dmcan_device_send_can_details`）。

        @param channel 通道号
        @param can_id 帧 ID
        @param interval_ms 发送间隔，单位毫秒；**0 = 只发一帧**
        @param payload 数据（0~64 字节）
        @param send_times 发送次数；0 = 不限（配合 `stop_send()` 停）
        @param canfd CAN FD 帧
        @param ext 扩展帧
        @param rtr 远程帧
        @param brs 启用 BRS

        @note 递增 ID / 数据递增的批量发送请用 `send_can_bulk()`（v1.x 那套 `step_id` / `stop_id` /
              `id_inc` / `data_inc` 参数已从本接口移除）。
        @note 停止周期任务用 `stop_send(channel)`。
        """
        data = b"" if rtr else bytes(payload)
        buffer = payload_buffer(data)
        self._check(self.dll.dmcan_device_send_can_details(self._handle, channel, interval_ms, send_times,
                                                           can_id, canfd, ext, rtr, brs, len(data), buffer),
                    "dmcan_device_send_can_details")

    def send_can_batch(self, channel: int, frames: Sequence[dmcan_frame]) -> None:
        """
        @brief 一次交一批帧（`dmcan_device_send_can_batch`，v1.x 两段式 `fill_can_queue` + `can_queue_send` 的替代）。

        @param channel 通道号
        @param frames 帧序列，用 `dmcan_frame.create()` 构造；空序列直接报错（C 侧也要求 count > 0）

        @note 参数校验是全部先做的：某一帧参数非法时整批拒收，不会只发出去前面几帧。
        """
        if not frames:
            raise ValueError("frames 不能为空")
        buffer = (dmcan_frame * len(frames))(*frames)
        self._check(self.dll.dmcan_device_send_can_batch(self._handle, channel, buffer, len(frames)),
                    "dmcan_device_send_can_batch")

    def send_can_bulk(self, channel: int, config: dmcan_bulk_send_config) -> None:
        """
        @brief 批量 / 递增发送（`dmcan_device_send_can_bulk`）。

        @param channel 通道号
        @param config 配置对象，用 `dmcan_bulk_send_config.create()` 构造（它会接管 payload 的生命周期）

        @note `send_times` 与 `stop_id` 谁先到谁停；`interval_ms = 0` 退化为只发一帧。
        """
        self._check(self.dll.dmcan_device_send_can_bulk(self._handle, channel, config),
                    "dmcan_device_send_can_bulk")

    def stop_send(self, channel: int) -> None:
        """
        @brief 停止该通道的周期发送任务（调度完全在 SDK 侧，不下发停止命令）。

        @param channel 通道号
        """
        self._check(self.dll.dmcan_device_stop_send(self._handle, channel), "dmcan_device_stop_send")

    def hook_recv_callback(self, callback: Callable[[Any, dmcan_rx_frame], None]) -> None:
        """
        @brief 注册收帧回调（旧式 hook，库侧已标记弃用但语义不变）。

        @param callback `callback(device, frame)`，`frame` 是 `dmcan_rx_frame`

        @note 回调在库自己的通知线程上**同步**执行：必须快速返回，不要在回调里落盘 / 重活 / 调 `close()`。
        @note `frame` 只在本次回调期间有效，要留存请自己拷（没拷就存引用是悬垂指针）。
        """
        self._recv_callback = callback

        @DEV_RECV_CALLBACK
        def wrapper(handle_ptr, frame_ptr):
            if frame_ptr:
                self._recv_callback(self, frame_ptr.contents)

        self._recv_cb_wrapper = wrapper
        self.dll.dmcan_device_hook_recv_callback(self._handle, wrapper)

    def hook_sent_callback(self, callback: Callable[[Any, dmcan_rx_frame], None]) -> None:
        """
        @brief 注册发送回执回调（旧式 hook）。

        @param callback `callback(device, frame)`

        @note 同一帧会来两条：`frame.ack = 0` 为假 echo（这笔 USB 提交已完成），`frame.ack = 1`
              为真 echo（固件回报已在总线上被确认），顺序恒为 0 → 1。
        """
        self._sent_callback = callback

        @DEV_SENT_CALLBACK
        def wrapper(handle_ptr, frame_ptr):
            if frame_ptr:
                self._sent_callback(self, frame_ptr.contents)

        self._sent_cb_wrapper = wrapper
        self.dll.dmcan_device_hook_sent_callback(self._handle, wrapper)

    def hook_err_callback(self, callback: Callable[[Any, dmcan_rx_frame], None]) -> None:
        """
        @brief 注册通道错误回调（旧式 hook）。

        @param callback `callback(device, frame)`

        @note 负载是 16B 的 `dmcan_channel_error_t` 原样装进帧里：`frame.dlen = 16`，
              `frame.payload` 前 16 字节即该记录（小端）。
        """
        self._error_callback = callback

        @DEV_ERR_CALLBACK
        def wrapper(handle_ptr, frame_ptr):
            if frame_ptr:
                self._error_callback(self, frame_ptr.contents)

        self._error_cb_wrapper = wrapper
        self.dll.dmcan_device_hook_err_callback(self._handle, wrapper)

    # ---------------------------------------------------------------- 2.0 新增：诊断 / 订阅 / 控制面

    def is_present(self) -> bool:
        """
        @brief 该设备当前是否还插在总线上（`dmcan_device_is_present`）。

        @return True = 还在；False = 已拔掉（**句柄仍然有效**，可直接查询或重新枚举）
        """
        present = c_bool(False)
        self._check(self.dll.dmcan_device_is_present(self._handle, byref(present)), "dmcan_device_is_present")
        return bool(present.value)

    def get_info(self) -> DmCanDeviceInfo:
        """
        @brief 读枚举信息：型号 / PID / VID / 序列号（`dmcan_device_get_info`）。

        @return `DmCanDeviceInfo`

        @note 读的是会话里缓存的枚举信息，**不需要 open**，也不与设备通信。
        """
        device_type = c_int(0)
        pid = c_int(0)
        vid = c_int(0)
        serial = POINTER(c_ubyte)()
        self.dll.dmcan_device_get_info(self._handle, byref(device_type), byref(pid), byref(vid),
                                       byref(serial))
        text = string_at(serial).decode("utf-8", errors="replace") if serial else ""
        return DmCanDeviceInfo(device_type_of(device_type.value), pid.value, vid.value, text)

    def get_channel_tdc(self, channel: int) -> dmcan_tdc_status:
        """
        @brief 读通道 TDC 的**硬件实际生效值**（`dmcan_device_get_channel_tdc`）。

        @param channel 通道号
        @return `dmcan_tdc_status`；`valid` 为真才代表读到了生效值

        @note 下发与生效不同步（固件每秒任务里重载，实测 0.086 ~ 1.0 s），刚下发完回读可能是旧值。
        """
        out = dmcan_tdc_status()
        self._check(self.dll.dmcan_device_get_channel_tdc(self._handle, channel, out),
                    "dmcan_device_get_channel_tdc")
        return out

    def save_param(self) -> None:
        """
        @brief 把当前运行期参数写进设备闪存（`dmcan_device_save_param`）。

        @note 无异常只代表固件**受理**了命令，实际写入由固件后台完成；要验证持久化请等一会儿再断电/拔插。
        """
        self._check(self.dll.dmcan_device_save_param(self._handle), "dmcan_device_save_param")

    def set_channel_filter(self, channel: int, mode, rules: Sequence[dmcan_filter_rule]) -> dmcan_filter_usage:
        """
        @brief 下发硬件过滤表（`dmcan_device_set_channel_filter`）。

        @param channel 通道号
        @param mode `dmcan_filter_mode` 取值
        @param rules 规则序列，最多 32 条（标准/扩展各 ≤ 16）；空序列 = 清空表（恢复全接受）
        @return 固件回的用量 `dmcan_filter_usage`

        @note **改表前必须先关通道**（`enable_channel(channel, False)`），改完再重新使能。
        @note 生效有延迟（固件每秒任务里重载，实测 0.086 ~ 1.0 s）；要落盘保留需另调 `save_param()`。
        """
        count = len(rules)
        buffer = (dmcan_filter_rule * count)(*rules) if count else None
        usage = dmcan_filter_usage()
        self._check(self.dll.dmcan_device_set_channel_filter(self._handle, channel, int(mode), buffer, count,
                                                             byref(usage)), "dmcan_device_set_channel_filter")
        return usage

    def get_channel_filter(self, channel: int) -> dmcan_filter_table:
        """
        @brief 回读硬件过滤表（`dmcan_device_get_channel_filter`）。

        @param channel 通道号
        @return `dmcan_filter_table`；只有 `rules[0:count]` 有效（空表是合法结果）
        """
        table = dmcan_filter_table()
        self._check(self.dll.dmcan_device_get_channel_filter(self._handle, channel, table),
                    "dmcan_device_get_channel_filter")
        return table

    def enable_watchdog(self, ms: int, state: bool) -> None:
        """
        @brief 开关设备看门狗（`dmcan_device_enable_watchdog`）。

        @param ms 超时时间，单位毫秒
        @param state True = 使能，False = 关闭
        """
        self._check(self.dll.dmcan_device_enable_watchdog(self._handle, ms, state), "dmcan_device_enable_watchdog")

    def subscribe(self, events, callback: Callable[[Any, DmCanEvent], None],
                  channel_mask: int = DMCAN_CHANNEL_MASK_ALL) -> DmCanSubscription:
        """
        @brief 订阅设备事件（`dmcan_device_subscribe`，2.0 推荐的接收路径）。

        @param events `dmcan_event_flag` 位或（RX_FRAME / TX_COMPLETED / TX_ON_BUS / CHANNEL_ERROR / UART_RX）
        @param callback `callback(device, event)`；`event` 是 `DmCanEvent`，帧/错误/UART 数据**已拷贝**
        @param channel_mask 关心的通道掩码，默认全部通道
        @return `DmCanSubscription`；`cancel()` 注销，或调 `unsubscribe(sub)`

        @note 可以在 `open()` 之前订阅；订阅挂在会话上，`close()` / 重新 `open()`（含拔插重连）都不会丢。
        @note 回调在 SDK 的通知线程上**同步**执行，必须快速返回；不要在回调里 `close()`（会被拒并置 REENTRANT）。
        @note 要带业务数据直接用闭包，不要指望 `user_data`（C 侧只收裸指针）。
        """
        config = dmcan_subscribe_config()
        config.events = int(events)
        config.channel_mask = int(channel_mask)
        config.user_data = None

        @DEV_EVENT_CALLBACK
        def wrapper(handle_ptr, event_ptr, user_data_ptr):
            if not event_ptr:
                return
            callback(self, _decode_event(event_ptr.contents))

        config.callback = cast(wrapper, c_void_p)
        subscription = POINTER(dmcan_subscription)()
        self._check(self.dll.dmcan_device_subscribe(self._handle, byref(config), byref(subscription)),
                    "dmcan_device_subscribe")
        return DmCanSubscription(self, subscription, wrapper, callback)

    def unsubscribe(self, subscription: DmCanSubscription) -> None:
        """
        @brief 注销订阅（`dmcan_device_unsubscribe`）。

        @param subscription `subscribe()` 返回的句柄
        """
        self._check(self.dll.dmcan_device_unsubscribe(self._handle, subscription._subscription),
                    "dmcan_device_unsubscribe")
        subscription._active = False

    def get_send_profile(self) -> dmcan_send_profile:
        """
        @brief 读发送聚合档位（`dmcan_device_get_send_profile`）。

        @return `dmcan_send_profile`
        """
        profile = c_int(0)
        self._check(self.dll.dmcan_device_get_send_profile(self._handle, byref(profile)),
                    "dmcan_device_get_send_profile")
        return dmcan_send_profile(profile.value)

    def set_send_profile(self, profile) -> None:
        """
        @brief 设置发送聚合档位（`dmcan_device_set_send_profile`，设备级、立即生效）。

        @param profile `dmcan_send_profile` 取值
        """
        self._check(self.dll.dmcan_device_set_send_profile(self._handle, int(profile)),
                    "dmcan_device_set_send_profile")

    def get_channel_ext_config(self, channel: int) -> dmcan_channel_ext_config:
        """
        @brief 读通道扩展配置：重传策略与 bus-off 自动恢复间隔（`dmcan_device_get_channel_ext_config`）。

        @param channel 通道号
        @return `dmcan_channel_ext_config`
        """
        config = dmcan_channel_ext_config()
        self._check(self.dll.dmcan_device_get_channel_ext_config(self._handle, channel, config),
                    "dmcan_device_get_channel_ext_config")
        return config

    def set_channel_ext_config(self, channel: int, config: dmcan_channel_ext_config) -> None:
        """
        @brief 写通道扩展配置（`dmcan_device_set_channel_ext_config`）。

        @param channel 通道号
        @param config 扩展配置；`busoff_autoreset_ms = 0` 表示 bus-off 后不自动恢复
        """
        self._check(self.dll.dmcan_device_set_channel_ext_config(self._handle, channel, config),
                    "dmcan_device_set_channel_ext_config")

    def get_module_features(self) -> dmcan_module_feature:
        """
        @brief 读模块能力位（`dmcan_device_get_module_features`）。

        @return `dmcan_module_feature` 位或；老固件/老硬件返回 0
        """
        features = c_uint16(0)
        self._check(self.dll.dmcan_device_get_module_features(self._handle, byref(features)),
                    "dmcan_device_get_module_features")
        return dmcan_module_feature(features.value)

    def enable_can_res(self, channel: int, state: bool) -> None:
        """
        @brief 开关软件终端电阻（`dmcan_device_enable_can_res`）。

        @param channel 通道号
        @param state True = 接通，False = 断开

        @note 协议要求**通道已使能**，否则这次写会被固件静默忽略（库会因此回失败）。
        @note 电阻状态**不写 flash**，设备重启/重新枚举后必须重新下发。
        """
        self._check(self.dll.dmcan_device_enable_can_res(self._handle, channel, state),
                    "dmcan_device_enable_can_res")

    def get_can_res(self, channel: int) -> bool:
        """
        @brief 读软件终端电阻当前状态（`dmcan_device_get_can_res`）。

        @param channel 通道号
        @return True = 已接通；老硬件（能力位为 0）恒回 False
        """
        enabled = c_bool(False)
        self._check(self.dll.dmcan_device_get_can_res(self._handle, channel, byref(enabled)),
                    "dmcan_device_get_can_res")
        return bool(enabled.value)

    def set_channel_echo(self, channel: int, enable: bool) -> None:
        """
        @brief 开关通道的总线 echo（真 echo，下发 `CMD_SET_ECHO`）。

        @param channel 通道号
        @param enable True = 打开
        """
        self._check(self.dll.dmcan_device_set_channel_echo(self._handle, channel, enable),
                    "dmcan_device_set_channel_echo")

    def get_echo_stats(self) -> dmcan_echo_stats:
        """
        @brief 读 echo 诊断计数（`dmcan_device_get_echo_stats`）。

        @return `dmcan_echo_stats`；计数在"设备打开"期间累计，重新打开后从 0 开始
        """
        stats = dmcan_echo_stats()
        self._check(self.dll.dmcan_device_get_echo_stats(self._handle, stats), "dmcan_device_get_echo_stats")
        return stats

    def set_echo_timeout_ms(self, timeout_ms: int) -> None:
        """
        @brief 设置真 echo 的超时阈值（`dmcan_device_set_echo_timeout_ms`，本机侧）。

        @param timeout_ms 超时时间，单位毫秒
        """
        self.dll.dmcan_device_set_echo_timeout_ms(self._handle, timeout_ms)

    def clear_bus_off(self, channel: int) -> None:
        """
        @brief 主动清除通道的 bus-off 状态（`dmcan_device_clear_bus_off`）。

        @param channel 通道号
        """
        self._check(self.dll.dmcan_device_clear_bus_off(self._handle, channel), "dmcan_device_clear_bus_off")

    def get_channel_stats(self, channel: int) -> Optional[dmcan_channel_stats]:
        """
        @brief 读通道统计快照（`dmcan_device_get_channel_stats`）。

        @param channel 通道号
        @return `dmcan_channel_stats`；**通道刚打开/首条周期上报还没到时返回 `None`**

        @note C 侧对"还没收到过上报"的语义是**不算调用失败**：返回 false 但错误码保持 `OK`
              （出参清零），让调用方靠返回值区分。本方法据此返回 `None`，而不是抛异常；
              真失败（未打开、参数非法等）仍抛 `DmCanError`。

        @note 值来自固件**周期上报**（每秒一条），最多旧 1 秒。
        @note 先看 `drop_flags` 再信细分字段：位为 0 表示那条记录还没到过，字段恒 0 **不代表没丢过帧**。
        """
        stats = dmcan_channel_stats()
        if not self.dll.dmcan_device_get_channel_stats(self._handle, channel, stats):
            if self.last_error() != dmcan_status.OK:
                raise DmCanError(self.last_error(), "dmcan_device_get_channel_stats")
            return None
        return stats

    def get_bus_state(self, channel: int) -> dmcan_bus_state:
        """
        @brief 读通道总线状态快照（`dmcan_device_get_bus_state`）。

        @param channel 通道号
        @return `dmcan_bus_state`；`bus_state` 取值 0=active 1=warning 2=passive 3=bus-off
        """
        state = dmcan_bus_state()
        self._check(self.dll.dmcan_device_get_bus_state(self._handle, channel, state),
                    "dmcan_device_get_bus_state")
        return state

    def clear_last_error(self) -> None:
        """@brief 把本线程的错误码清成 `dmcan_status.OK`（`dmcan_clear_last_error`）。"""
        self.dll.dmcan_clear_last_error()

    # ---------------------------------------------------------------- 2.0 新增：USB2UART 透传

    def set_uart_auto_open(self, enable: bool) -> None:
        """
        @brief 开关"打开设备时自动打开 UART"（`dmcan_device_set_uart_auto_open`，默认开）。

        @param enable False = 不自动打开

        @note 只对**下一次** `open()` 生效；要立刻关掉已打开的端口用 `uart_close()`。
        """
        self._check(self.dll.dmcan_device_set_uart_auto_open(self._handle, enable), "dmcan_device_set_uart_auto_open")

    def set_uart_config(self, config: dmcan_uart_config) -> None:
        """
        @brief 设置 UART 线参数（`dmcan_device_set_uart_config`，存下来给"自动打开"用）。

        @param config 线参数；`baud_rate = 0` 表示不改（沿用设备当前配置）
        """
        self._check(self.dll.dmcan_device_set_uart_config(self._handle, config), "dmcan_device_set_uart_config")

    def uart_is_open(self) -> bool:
        """
        @brief 查询 UART 端口是否已打开（`dmcan_device_uart_is_open`）。

        @return True = 已打开
        """
        is_open = c_bool(False)
        self._check(self.dll.dmcan_device_uart_is_open(self._handle, byref(is_open)), "dmcan_device_uart_is_open")
        return bool(is_open.value)

    def uart_get_port_name(self) -> str:
        """
        @brief 取当前 UART 端口名（`dmcan_device_uart_get_port_name`），例如 `COM70` / `/dev/ttyACM0`。

        @return 端口名；没打开时为空串（库返回 false，本方法返回空串而不是抛异常）
        """
        buffer = create_string_buffer(256)
        if not self.dll.dmcan_device_uart_get_port_name(self._handle, buffer, len(buffer)):
            return ""
        return buffer.value.decode("utf-8", errors="replace")

    def uart_open(self, config: Optional[dmcan_uart_config] = None) -> None:
        """
        @brief 手动打开 UART 端口（`dmcan_device_uart_open`，按 VID/PID + 序列号找本机那个）。

        @param config 线参数；`None` 表示用 `set_uart_config()` 存的那份（默认 115200 8N1）

        @note 打开后该 COM 口被本进程**独占**，app 侧脚本 / 串口助手打不开。
        """
        self._check(self.dll.dmcan_device_uart_open(self._handle, config), "dmcan_device_uart_open")

    def uart_close(self) -> None:
        """@brief 关闭 UART 端口（`dmcan_device_uart_close`，可重复调用；最多等一个读超时约 100 ms）。"""
        self.dll.dmcan_device_uart_close(self._handle)

    def uart_write(self, data: bytes) -> None:
        """
        @brief 往 UART 写一段数据（`dmcan_device_uart_write`，同步；写不完算失败）。

        @param data 待发送字节

        @note 收数据走订阅：`subscribe(dmcan_event_flag.UART_RX, ...)`。
        """
        buffer = payload_buffer(bytes(data))
        self._check(self.dll.dmcan_device_uart_write(self._handle, buffer, len(data)), "dmcan_device_uart_write")

    def get_uart_stats(self) -> dmcan_uart_stats:
        """
        @brief 读 UART 统计（`dmcan_device_get_uart_stats`）。

        @return `dmcan_uart_stats`：收发字节数、丢字节数、错误次数、是否打开
        """
        stats = dmcan_uart_stats()
        self._check(self.dll.dmcan_device_get_uart_stats(self._handle, stats), "dmcan_device_get_uart_stats")
        return stats
